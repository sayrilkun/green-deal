import React from "react";
import { createStackNavigator,  } from "@react-navigation/stack";
import { NavigationContainer, DefaultTheme } from "@react-navigation/native";
import { useFonts } from "expo-font";
import { createNativeStackNavigator } from '@react-navigation/native-stack';
// import { BottomTab } from "./navigation/TabNavigator";

import BottomTab from "./navigation/BottomTabNavigator"
import Details from "./screens/Details";
import SignIn from "./screens/SignIn";

import Home from "./screens/Home";

// const MySwitchNavigator = createSwitchNavigator({
//   routeOne: SignIn,
//   // routeTwo: ScreenTwo,
//   // routeThree: ScreenThree,
// });
const Stack = createNativeStackNavigator();


const theme = {
  ...DefaultTheme,
  colors: {
    ...DefaultTheme.colors,
    background: "transparent",
  },
};


const App = () => {
  const [loaded] = useFonts({
    InterBold: require("./assets/fonts/Inter-Bold.ttf"),
    InterSemiBold: require("./assets/fonts/Inter-SemiBold.ttf"),
    InterMedium: require("./assets/fonts/Inter-Medium.ttf"),
    InterRegular: require("./assets/fonts/Inter-Regular.ttf"),
    InterLight: require("./assets/fonts/Inter-Light.ttf"),
  });

  if (!loaded) return null;

  return (
    <NavigationContainer theme={theme} intialRouteName="SignIn">
      <Stack.Screen name="SignIn" component={SignIn} />
      <BottomTab />
    </NavigationContainer>
  );
};

export default App;


{/* <Stack.Navigator
screenOptions={{
  headerShown: false,
}}
initialRouteName="Home"
>
  <Stack.Screen name="Home" component={Home} />
  <Stack.Screen name="Details" component={Details} />
</Stack.Navigator>  */}