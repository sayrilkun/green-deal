import React from "react";
import { View, Text, Image, TextInput } from "react-native";
import { NavigationContainer } from '@react-navigation/native';
import { createMaterialBottomTabNavigator } from '@react-navigation/material-bottom-tabs';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { COLORS, FONTS, SIZES, assets } from "../constants";
import { MainStackNavigator, QRStackNavigator, ProfileStackNavigator, LocationStackNavigator } from "./StackNavigator"


const Tab = createMaterialBottomTabNavigator();

const BottomTab = () => {
  return (
    <Tab.Navigator
      initialRouteName="Main"
      activeColor="#001F2D"
      labelStyle={{ fontSize: 12 }}
      barStyle={{ backgroundColor: 'white' }}
      
    >
      <Tab.Screen
        name="Main"
        component={MainStackNavigator}
        options={{
          tabBarVisible :'false',
          tabBarLabel: 'Main',
          tabBarIcon: ({ color }) => (
            <MaterialCommunityIcons name="home" color={color} size={26} />
          ),
        }}
      />
      <Tab.Screen
        name="Location"
        component={LocationStackNavigator}
        options={{
          tabBarLabel: 'Location',
          tabBarIcon: ({ color }) => (
            <MaterialCommunityIcons name="map" color={color} size={26} />
          ),
        }}
      />
      <Tab.Screen
        name="QR"
        component={QRStackNavigator}
        options={{
          tabBarLabel: 'QR',
          tabBarIcon: ({ color }) => (
            <MaterialCommunityIcons name="qrcode" color={color} size={26} />
          ),
        }}
      />
      <Tab.Screen
        name="Profile"
        component={ProfileStackNavigator}
        options={{
          tabBarLabel: 'Profile',
          tabBarIcon: ({ color }) => (
            <MaterialCommunityIcons name="account" color={color} size={26} />
          ),
        }}
      />
    </Tab.Navigator>
  );
}

export default BottomTab;